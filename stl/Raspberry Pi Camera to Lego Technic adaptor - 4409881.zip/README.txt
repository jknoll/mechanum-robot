Raspberry Pi Camera to Lego Technic adaptor by ralphius on Thingiverse: https://www.thingiverse.com/thing:4409881

Summary:
Holds a Raspberry Pi camera securely. Requires 2x M2 nuts and bolts. Has 2 Lego Technic pin holes on the back at the required spacing. Lens is centered exactly between the holes so recommend using "Technic double pin with perpendicular axle hole" (#32138) to go in the back as shown in photo.Does not require supports and can be printed with a 0.4mm nozzle.Sketchup CAD source file included for those that wish to tweak the design.